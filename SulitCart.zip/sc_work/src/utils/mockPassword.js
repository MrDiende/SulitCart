const iterations = 600000;
const toHex = (bytes) => Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
const fromHex = (value) => Uint8Array.from(value.match(/.{2}/g), (byte) => parseInt(byte, 16));

async function derivePassword(password, salt, rounds) {
  if (!globalThis.crypto?.subtle) {
    throw new Error("Password setup requires HTTPS or localhost. Open the prototype there and try again.");
  }
  const key = await globalThis.crypto.subtle.importKey(
    "raw", new TextEncoder().encode(password), { name: "PBKDF2" }, false, ["deriveBits"],
  );
  const bits = await globalThis.crypto.subtle.deriveBits(
    { name: "PBKDF2", salt, iterations: rounds, hash: "SHA-256" }, key, 256,
  );
  return toHex(new Uint8Array(bits));
}

// Local prototype credentials only; production authentication belongs in Supabase.
export async function createMockPasswordCredential(password) {
  const salt = globalThis.crypto.getRandomValues(new Uint8Array(16));
  return { algorithm: "PBKDF2", iterations, salt: toHex(salt), digest: await derivePassword(password, salt, iterations) };
}

export async function verifyMockPassword(password, credential) {
  if (credential?.algorithm !== "PBKDF2"
    || !/^[a-f0-9]{32}$/i.test(credential.salt || "")
    || !/^[a-f0-9]{64}$/i.test(credential.digest || "")
    || !Number.isSafeInteger(credential.iterations)
    || credential.iterations < 1
    || credential.iterations > 1000000) return false;
  const digest = await derivePassword(password, fromHex(credential.salt), credential.iterations);
  return digest === credential.digest.toLowerCase();
}