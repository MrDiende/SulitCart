import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { mockCustomers } from "../data/mockCustomers";
import { mockShipping } from "../data/mockShipping";
import { mockStaff } from "../data/mockStaff";
import { mockUsers } from "../data/mockUsers";
import { catalogVersion, loadMockCatalog } from "../data/catalogStorage";
import { isOnlineOrder, readStorage } from "../utils";
import { generateProductCode } from "../utils/productCode";
import { createMockPasswordCredential, verifyMockPassword } from "../utils/mockPassword";
import { mockSessionKey, persistMockAccounts, persistMockSession, publicSessionUser, restoreMockSession } from "../services/mockSession";

const StoreContext = createContext(null);

function loadUsers() {
  const savedUsers = readStorage("sulitcart:users", mockUsers);
  if (!Array.isArray(savedUsers)) return mockUsers;
  const seeded = mockUsers.map((account) => savedUsers.find((saved) => saved.id === account.id || saved.email?.toLowerCase() === account.email.toLowerCase()) || account);
  const additional = savedUsers.filter((saved) => !seeded.some((account) => account.id === saved.id || account.email.toLowerCase() === saved.email?.toLowerCase()));
  return [...seeded, ...additional];
}

function persistProducts(products) {
  try {
    window.localStorage.setItem("sulitcart:products", JSON.stringify(products));
    return null;
  } catch (error) {
    return { error: error.name === "QuotaExceededError"
      ? "Browser storage is full. Remove an unused uploaded image or product and try again."
      : "Browser storage is unavailable. Allow local storage before saving this change." };
  }
}

export function StoreProvider({ children }) {
  const [initialCatalog] = useState(loadMockCatalog);
  const [products, setProducts] = useState(initialCatalog.products);
  const [categories, setCategories] = useState(initialCatalog.categories);
  const [orders, setOrders] = useState(initialCatalog.orders);
  const [customers, setCustomers] = useState(() => readStorage("sulitcart:customers", mockCustomers));
  const [staff, setStaff] = useState(() => readStorage("sulitcart:staff", mockStaff));
  const [shipping, setShipping] = useState(() => readStorage("sulitcart:shipping", mockShipping));
  const [inventory, setInventory] = useState(initialCatalog.inventory);
  const [users, setUsers] = useState(loadUsers);
  const [cart, setCart] = useState(initialCatalog.cart);
  const [user, setUser] = useState(() => restoreMockSession(users));
  const [storageError, setStorageError] = useState("");
  const [auditLogs, setAuditLogs] = useState(initialCatalog.audit);

  const customerAccount = users.find((account) => account.id === user?.id);
  const customerRecord = user && customers.find((customer) => customer.id === user.id || customer.email.toLowerCase() === user.email.toLowerCase());
  const canCheckout = Boolean(user?.role === "customer"
    && user.active !== false
    && customerAccount?.role === "customer"
    && customerAccount.active !== false
    && customerRecord?.active !== false);

  useEffect(() => {
    const persisted = { products, categories, orders, customers, staff, shipping, inventory, users, cart, audit: auditLogs };
    let failed = false;
    Object.entries(persisted).forEach(([key, value]) => {
      try {
        window.localStorage.setItem(`sulitcart:${key}`, JSON.stringify(value));
      } catch {
        failed = true;
      }
    });
    if (!failed) {
      try {
        window.localStorage.setItem("sulitcart:catalog-version", JSON.stringify(catalogVersion));
      } catch {
        failed = true;
      }
    }
    setStorageError(failed ? "Some changes could not be saved locally. Free up browser storage before refreshing." : "");
  }, [products, categories, orders, customers, staff, shipping, inventory, users, cart, auditLogs]);

  useEffect(() => {
    const restoreSession = () => {
      const savedAccounts = loadUsers();
      setUsers(savedAccounts);
      setUser(restoreMockSession(savedAccounts));
    };
    const handleStorage = (event) => {
      if (event.key === mockSessionKey || event.key === "sulitcart:users" || event.key === null) restoreSession();
    };
    const handlePageShow = (event) => {
      if (event.persisted) restoreSession();
    };
    window.addEventListener("storage", handleStorage);
    window.addEventListener("pageshow", handlePageShow);
    return () => {
      window.removeEventListener("storage", handleStorage);
      window.removeEventListener("pageshow", handlePageShow);
    };
  }, []);

  const addAudit = useCallback((action, entity, description, actor = user) => {
    setAuditLogs((current) => [{
      id: `log-${Date.now()}`,
      date: new Date().toISOString(),
      user: actor?.name || "Guest",
      role: actor?.role ? actor.role.charAt(0).toUpperCase() + actor.role.slice(1) : "Customer",
      action,
      entity,
      description,
    }, ...current]);
  }, [user]);

  const addToCart = useCallback((productId, quantity = 1) => {
    const product = products.find((item) => item.id === productId);
    if (!product || !product.active || product.stock < 1) return false;
    const existing = cart.find((item) => item.productId === productId)?.quantity || 0;
    if (existing + quantity > product.stock) return false;
    setCart((current) => {
      const match = current.find((item) => item.productId === productId);
      return match
        ? current.map((item) => item.productId === productId ? { ...item, quantity: item.quantity + quantity } : item)
        : [...current, { productId, quantity }];
    });
    return true;
  }, [cart, products]);

  const updateCartQuantity = useCallback((productId, quantity) => {
    if (quantity <= 0) {
      setCart((current) => current.filter((item) => item.productId !== productId));
      return;
    }
    const product = products.find((item) => item.id === productId);
    const safeQuantity = Math.min(quantity, product?.stock || 0);
    setCart((current) => current.map((item) => item.productId === productId ? { ...item, quantity: safeQuantity } : item));
  }, [products]);

  const getShippingFee = useCallback((municipality, barangay) => {
    if (!municipality) return 0;
    const activeRates = shipping.filter((rate) => rate.active && rate.municipality === municipality);
    const exact = activeRates.find((rate) => rate.barangay.toLowerCase() === (barangay || "").trim().toLowerCase());
    return exact?.fee ?? activeRates.find((rate) => rate.barangay === "*")?.fee ?? 0;
  }, [shipping]);

  const upsertProduct = (product) => {
    const isNew = !product.id;
    const previous = products.find((item) => item.id === product.id);
    if (!isNew && !previous) return { error: "This product no longer exists. Refresh the product list." };
    if (!product.category) return { error: "Choose a category to generate a product code." };
    const productCode = previous?.sku?.trim().toUpperCase() || generateProductCode(products, product.category, categories);
    if (products.some((item) => item.id !== product.id && item.sku?.toUpperCase() === productCode)) return { error: "This product code is already in use." };
    const nextProduct = { ...product, sku: productCode, id: product.id || `p-${Date.now()}`, stock: Number(product.stock), price: Number(product.price), threshold: Number(product.threshold) };
    if (!Number.isSafeInteger(nextProduct.stock) || nextProduct.stock < 0 || !Number.isSafeInteger(nextProduct.threshold) || nextProduct.threshold < 0 || !Number.isFinite(nextProduct.price) || nextProduct.price < 0) {
      return { error: "Enter a valid price and non-negative whole numbers for stock and threshold." };
    }
    const nextProducts = isNew ? [nextProduct, ...products] : products.map((item) => item.id === nextProduct.id ? nextProduct : item);
    const persistenceError = persistProducts(nextProducts);
    if (persistenceError) return persistenceError;
    setProducts(nextProducts);
    const stockDifference = nextProduct.stock - (previous?.stock || 0);
    if (stockDifference) {
      setInventory((current) => [{
        id: `tx-${Date.now()}-${nextProduct.id}`,
        productId: nextProduct.id,
        type: isNew ? "Initial stock" : stockDifference > 0 ? "Stock received" : "Stock adjustment",
        quantity: stockDifference,
        date: new Date().toISOString(),
        user: user?.name || "Admin",
        note: isNew ? `Initial stock for ${productCode}` : `Stock updated through product form (${productCode})`,
      }, ...current]);
    }
    addAudit(isNew ? "Product added" : "Product updated", nextProduct.name, `${nextProduct.sku} product details saved`);
    return nextProduct;
  };

  const deleteProduct = (id) => {
    const product = products.find((item) => item.id === id);
    setProducts((current) => current.filter((item) => item.id !== id));
    setCart((current) => current.filter((item) => item.productId !== id));
    addAudit("Product deleted", product?.name || id, "Product removed from catalog");
  };

  const upsertCategory = (category) => {
    const isNew = !category.id;
    const nextCategory = { ...category, id: category.id || `cat-${Date.now()}` };
    setCategories((current) => isNew ? [...current, nextCategory] : current.map((item) => item.id === nextCategory.id ? nextCategory : item));
    addAudit(isNew ? "Category added" : "Category updated", nextCategory.name, "Category details saved");
  };

  const deleteCategory = (id) => {
    const category = categories.find((item) => item.id === id);
    setCategories((current) => current.filter((item) => item.id !== id));
    addAudit("Category deleted", category?.name || id, "Category removed from catalog");
  };

  const changeOrderStatus = (orderId, status) => {
    const order = orders.find((item) => item.id === orderId);
    if (!order || !isOnlineOrder(order)) return;
    setOrders((current) => current.map((item) => item.id === orderId ? { ...item, status } : item));
    addAudit("Order status changed", order.number, `${order.status} to ${status}`);
  };

  const placeOrder = ({ customer, address, phone, municipality, barangay, notes, payment = "Cash on Delivery" }) => {
    if (!canCheckout) return { error: "Please sign in to your customer account before checkout.", requiresSignIn: true };
    const orderLines = cart.map((line) => {
      const product = products.find((item) => item.id === line.productId);
      return product ? { productId: product.id, name: product.name, image: product.image, price: product.price, quantity: line.quantity } : null;
    }).filter(Boolean);
    if (!orderLines.length || orderLines.some((line) => line.quantity > (products.find((product) => product.id === line.productId)?.stock || 0))) return null;
    const subtotal = orderLines.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const shippingFee = getShippingFee(municipality, barangay);
    const order = {
      id: `o-${Date.now()}`,
      number: `SC-${new Date().getFullYear()}-${String(orders.length + 1049).padStart(4, "0")}`,
      channel: "online",
      customerId: user.id,
      customer: customer || user.name,
      email: user.email,
      date: new Date().toISOString(),
      items: orderLines,
      subtotal,
      shipping: shippingFee,
      total: subtotal + shippingFee,
      payment,
      status: "Pending",
      address: [barangay, municipality, "Nueva Ecija", address].filter(Boolean).join(", "),
      municipality,
      barangay,
      phone,
      notes,
    };
    setOrders((current) => [order, ...current]);
    setProducts((current) => current.map((product) => {
      const sold = orderLines.find((line) => line.productId === product.id)?.quantity || 0;
      return sold ? { ...product, stock: product.stock - sold } : product;
    }));
    const transactionDate = new Date().toISOString();
    setInventory((current) => [
      ...orderLines.map((line) => ({ id: `tx-${Date.now()}-${line.productId}`, productId: line.productId, type: "Online order", quantity: -line.quantity, date: transactionDate, user: customer || user?.name || "Customer", note: order.number })),
      ...current,
    ]);
    setCart([]);
    addAudit("Order placed", order.number, `${orderLines.length} product types, ${order.status}`);
    return order;
  };

  const commitSale = ({ items, customerName, payment }) => {
    const staffAccount = users.find((account) => account.id === user?.id);
    const staffMember = staff.find((person) => person.email.toLowerCase() === user?.email?.toLowerCase());
    if (user?.role !== "staff" || user.active === false || staffAccount?.active === false || staffMember?.active === false) {
      return { error: "Only active staff accounts can process walk-in sales." };
    }
    const lines = items.map((item) => {
      const product = products.find((productItem) => productItem.id === item.productId);
      return product ? { productId: product.id, name: product.name, image: product.image, price: product.price, quantity: item.quantity } : null;
    }).filter(Boolean);
    if (!lines.length || lines.some((line) => line.quantity > (products.find((product) => product.id === line.productId)?.stock || 0))) return null;
    const subtotal = lines.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const sale = {
      id: `sale-${Date.now()}`,
      number: `POS-${String(Date.now()).slice(-5)}`,
      channel: "walk-in",
      customerId: "walk-in",
      customer: customerName || "Walk-in customer",
      date: new Date().toISOString(),
      items: lines,
      subtotal,
      shipping: 0,
      total: subtotal,
      payment,
      status: "Completed",
      address: "Walk-in sale",
      processedBy: user.name,
      staffId: user.id,
    };
    setOrders((current) => [sale, ...current]);
    setProducts((current) => current.map((product) => {
      const sold = lines.find((line) => line.productId === product.id)?.quantity || 0;
      return sold ? { ...product, stock: product.stock - sold } : product;
    }));
    const transactionDate = new Date().toISOString();
    setInventory((current) => [
      ...lines.map((line) => ({ id: `tx-${Date.now()}-${line.productId}`, productId: line.productId, type: "Walk-in sale", quantity: -line.quantity, date: transactionDate, user: user?.name || "Staff", note: sale.number })),
      ...current,
    ]);
    addAudit("Walk-in sale", sale.number, `${lines.length} product types sold for PHP ${subtotal.toFixed(2)}`);
    return sale;
  };

  const adjustStock = (productId, difference, note = "Manual stock adjustment") => {
    const product = products.find((item) => item.id === productId);
    if (!product) return { error: "The selected product no longer exists." };
    const actualDifference = Number(difference);
    const quantity = Number(product.stock) + actualDifference;
    if (!Number.isSafeInteger(actualDifference) || !actualDifference || !Number.isSafeInteger(quantity) || quantity < 0) {
      return { error: "Enter a valid whole-number quantity. Stock cannot be negative." };
    }
    const productCode = (product.sku || "").trim() || generateProductCode(products, product.category, categories);
    if (!productCode) return { error: "Assign this product to a category before adding stock." };
    const nextProducts = products.map((item) => item.id === productId ? { ...item, sku: productCode, stock: quantity } : item);
    const persistenceError = persistProducts(nextProducts);
    if (persistenceError) return persistenceError;
    setProducts(nextProducts);
    const entry = { id: `tx-${Date.now()}`, productId, type: actualDifference >= 0 ? "Stock received" : "Stock adjustment", quantity: actualDifference, date: new Date().toISOString(), user: user?.name || "Admin", note };
    setInventory((current) => [entry, ...current]);
    addAudit(entry.type, product.name, `${actualDifference > 0 ? "+" : ""}${actualDifference} units. ${note}`);
    return entry;
  };

  const toggleCustomer = (id) => {
    const customer = customers.find((item) => item.id === id);
    if (!customer) return;
    const active = !customer.active;
    setCustomers((current) => current.map((item) => item.id === id ? { ...item, active } : item));
    setUsers((current) => current.map((item) => item.email.toLowerCase() === customer.email.toLowerCase() ? { ...item, active } : item));
    addAudit(active ? "Customer activated" : "Customer deactivated", customer.email, "Customer account status changed");
  };
  const upsertStaff = async (person) => {
    const previous = person.id ? staff.find((item) => item.id === person.id) : null;
    if (person.id && !previous) return { error: "This staff member no longer exists." };
    const name = person.name?.trim() || "";
    const email = person.email?.trim().toLowerCase() || "";
    const phone = person.phone?.trim() || "";
    const password = person.password || "";
    const existingAccount = previous ? users.find((item) => item.staffId === previous.id || item.id === previous.id || item.email.toLowerCase() === previous.email.toLowerCase()) : null;
    if (!name || !phone || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: "Enter a full name, valid email, and phone number." };
    if (staff.some((item) => item.id !== person.id && item.email.toLowerCase() === email)
      || users.some((item) => item.id !== existingAccount?.id && item.email.toLowerCase() === email)) {
      return { error: "An account with this email already exists." };
    }
    if ((!previous || password) && (password.length < 8 || !password.trim())) return { error: "Use a staff password with at least 8 characters." };
    let credentials = existingAccount?.credentials;
    if (password) {
      try {
        credentials = await createMockPasswordCredential(password);
      } catch (error) {
        return { error: error.message || "Could not set the staff password. Please try again." };
      }
    }
    const nextPerson = {
      id: previous?.id || `s-${Date.now()}`,
      name, email, phone,
      active: previous ? person.active !== false : true,
      created: previous?.created || new Date().toISOString().slice(0, 10),
    };
    const nextAccount = {
      ...existingAccount,
      id: existingAccount?.id || nextPerson.id,
      staffId: nextPerson.id,
      name, email, phone, active: nextPerson.active, role: "staff",
      ...(credentials ? { credentials } : {}),
    };
    const nextAccounts = existingAccount ? users.map((item) => item.id === existingAccount.id ? nextAccount : item) : [nextAccount, ...users];
    const accountError = persistMockAccounts(nextAccounts);
    if (accountError) return accountError;
    setStaff((current) => previous ? current.map((item) => item.id === previous.id ? nextPerson : item) : [nextPerson, ...current]);
    setUsers(nextAccounts);
    addAudit(person.id ? "Staff updated" : "Staff added", nextPerson.email, `${nextPerson.name} staff account saved`);
    return nextPerson;
  };
  const toggleStaff = (id) => {
    const person = staff.find((item) => item.id === id);
    if (!person) return;
    const active = !person.active;
    setStaff((current) => current.map((item) => item.id === id ? { ...item, active } : item));
    setUsers((current) => current.map((item) => item.email.toLowerCase() === person.email.toLowerCase() ? { ...item, active } : item));
    addAudit(active ? "Staff activated" : "Staff deactivated", person.email, "Staff account status changed");
  };
  const upsertShippingRate = (rate) => {
    const nextRate = rate.id ? { ...rate, fee: Number(rate.fee) || 0 } : { ...rate, id: `sh-${Date.now()}`, fee: Number(rate.fee) || 0, active: true };
    setShipping((current) => rate.id ? current.map((item) => item.id === rate.id ? nextRate : item) : [nextRate, ...current]);
    addAudit(rate.id ? "Shipping rate updated" : "Shipping rate added", nextRate.municipality, `${nextRate.barangay}: PHP ${nextRate.fee}`);
  };
  const deleteShippingRate = (id) => {
    const rate = shipping.find((item) => item.id === id);
    setShipping((current) => current.filter((item) => item.id !== id));
    addAudit("Shipping rate deleted", rate?.municipality || id, rate?.barangay || "Rate removed");
  };

  const login = async (email, password) => {
    if (!email || !password) return { error: "Enter your email and password to continue." };
    const matched = users.find((item) => item.email.toLowerCase() === email.trim().toLowerCase());
    if (!matched) return { error: "We could not find that account. Create an account to get started." };
    if (matched.active === false) return { error: "This account is inactive. Please contact the store team." };
    if (matched.credentials) {
      try {
        if (!await verifyMockPassword(password, matched.credentials)) return { error: "Incorrect password. Please try again." };
      } catch (error) {
        return { error: error.message || "Could not check your password. Please try again." };
      }
    }
    const signedIn = publicSessionUser(matched);
    if (!persistMockSession(signedIn)) return { error: "Your sign-in could not be saved. Enable browser storage and try again." };
    setUser(signedIn);
    addAudit("Signed in", email, "Mock account sign in", signedIn);
    return { user: signedIn };
  };

  const register = ({ name, email, password, phone }) => {
    if (!name?.trim() || !email?.trim() || !password || !phone?.trim()) return { error: "Complete all required fields." };
    if (password.length < 8) return { error: "Use a password with at least 8 characters." };
    if (users.some((item) => item.email.toLowerCase() === email.toLowerCase())) return { error: "An account with that email already exists." };
    const newUser = { id: `u-${Date.now()}`, name: name.trim(), email: email.trim(), phone: phone.trim(), role: "customer", active: true };
    const nextAccounts = [newUser, ...users];
    const accountError = persistMockAccounts(nextAccounts);
    if (accountError) return accountError;
    if (!persistMockSession(newUser)) {
      persistMockAccounts(users);
      return { error: "Your sign-in could not be saved. Enable browser storage and try again." };
    }
    setUsers(nextAccounts);
    setCustomers((current) => [...current, { ...newUser, address: "", joined: new Date().toISOString().slice(0, 10) }]);
    setUser(newUser);
    addAudit("Account created", newUser.email, "Customer account registered", newUser);
    return { user: newUser };
  };

  const updateProfile = (changes) => {
    if (!user) return;
    const updated = { ...user, ...changes };
    const nextAccounts = users.map((item) => item.id === updated.id ? { ...item, ...updated } : item);
    const accountError = persistMockAccounts(nextAccounts);
    if (accountError) return accountError;
    if (!persistMockSession(updated)) {
      persistMockAccounts(users);
      return { error: "Your session could not be saved. Enable browser storage and try again." };
    }
    setUser(updated);
    setUsers(nextAccounts);
    if (updated.role === "customer") setCustomers((current) => current.map((item) => item.email === updated.email ? { ...item, name: updated.name, phone: updated.phone, address: updated.address || item.address } : item));
    return updated;
  };

  const logout = () => {
    persistMockSession(null);
    setUser(null);
  };

  const value = {
    products, setProducts, categories, setCategories, orders, setOrders, customers, setCustomers, staff, setStaff,
    shipping, setShipping, inventory, setInventory, users, cart, user, canCheckout, storageError, auditLogs, addAudit, addToCart,
    updateCartQuantity, getShippingFee, upsertProduct, deleteProduct, upsertCategory, deleteCategory,
    changeOrderStatus, placeOrder, commitSale, adjustStock, toggleCustomer, upsertStaff, upsertShippingRate,
    deleteShippingRate, login, register, updateProfile, logout, toggleStaff,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error("useStore must be used inside StoreProvider");
  return context;
}