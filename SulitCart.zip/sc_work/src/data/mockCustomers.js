export const mockCustomers = [
  { id: "u-100", name: "Jamie Rivera", email: "customer@sulitcart.ph", phone: "0917 123 4567", address: "Kapitan Pepe, Cabanatuan City", active: true, joined: "2025-01-09" },
  { id: "u-101", name: "Maria Santos", email: "maria.santos@email.com", phone: "0917 234 5678", address: "Kapitan Pepe, Cabanatuan City", active: true, joined: "2024-11-06" },
  { id: "u-102", name: "Jose Dela Cruz", email: "jose.dc@email.com", phone: "0920 555 0192", address: "San Isidro, Gapan City", active: true, joined: "2024-12-14" },
  { id: "u-103", name: "Ana Reyes", email: "ana.reyes@email.com", phone: "0998 110 6084", address: "Bangad, Cabanatuan City", active: true, joined: "2025-01-21" },
  { id: "u-104", name: "Paolo Garcia", email: "paolo.g@email.com", phone: "0919 876 1023", address: "San Roque, San Jose City", active: true, joined: "2025-02-05" },
  { id: "u-105", name: "Liza Mendoza", email: "liza.m@email.com", phone: "0918 223 4477", address: "San Isidro, Talavera", active: false, joined: "2025-02-18" },
  { id: "u-106", name: "Ramon Cruz", email: "ramon.cruz@email.com", phone: "0908 312 6712", address: "Sumacab, Cabanatuan City", active: true, joined: "2025-03-02" },
];