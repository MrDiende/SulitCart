export const mockShipping = [
  { id: "sh-1", municipality: "Cabanatuan City", barangay: "*", fee: 50, active: true },
  { id: "sh-2", municipality: "Cabanatuan City", barangay: "Kapitan Pepe", fee: 50, active: true },
  { id: "sh-3", municipality: "Cabanatuan City", barangay: "Sumacab", fee: 55, active: true },
  { id: "sh-4", municipality: "Gapan City", barangay: "*", fee: 60, active: true },
  { id: "sh-5", municipality: "Palayan City", barangay: "*", fee: 65, active: true },
  { id: "sh-6", municipality: "San Jose City", barangay: "*", fee: 75, active: true },
  { id: "sh-7", municipality: "Santa Rosa", barangay: "*", fee: 65, active: true },
  { id: "sh-8", municipality: "Talavera", barangay: "*", fee: 60, active: true },
  { id: "sh-9", municipality: "Bongabon", barangay: "*", fee: 85, active: true },
];