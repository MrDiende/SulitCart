export const mockStaff = [
  { id: "s-001", name: "Marco Santos", email: "staff@sulitcart.ph", phone: "0917 555 0200", active: true, created: "2024-09-02" },
  { id: "s-002", name: "Nina Flores", email: "nina@sulitcart.ph", phone: "0922 105 8854", active: true, created: "2024-10-15" },
  { id: "s-003", name: "Eli Ramos", email: "eli.ramos@sulitcart.ph", phone: "0991 048 2100", active: false, created: "2025-01-08" },
];