import { readStorage } from "../utils";
import { mockAuditLogs } from "./mockAuditLogs";
import { mockCategories } from "./mockCategories";
import { mockInventory } from "./mockInventory";
import { mockOrders } from "./mockOrders";
import { mockProducts } from "./mockProducts";

export const catalogVersion = "retail-catalog-v1";
const legacyProductIds = new Set(Array.from({ length: 12 }, (_, index) => `p-${String(index + 1).padStart(3, "0")}`));
const legacyCategoryIds = new Set(["produce", "pantry", "dairy", "bakery", "meat", "household"]);

function readArray(key, fallback) {
  const saved = readStorage(`sulitcart:${key}`, fallback);
  return Array.isArray(saved) ? saved : fallback;
}

function mergeCatalog(saved, defaults) {
  const defaultIds = new Set(defaults.map((item) => item.id));
  return [
    ...defaults.map((item) => saved.find((record) => record.id === item.id) || item),
    ...saved.filter((item) => !defaultIds.has(item.id)),
  ];
}

function refreshSampleRecords(saved, defaults) {
  const replacements = new Map(defaults.map((item) => [item.id, item]));
  return [
    ...saved.map((item) => replacements.has(item.id)
      ? { ...replacements.get(item.id), ...(item.status ? { status: item.status } : {}) }
      : item),
    ...defaults.filter((item) => !saved.some((record) => record.id === item.id)),
  ];
}

export function loadMockCatalog() {
  const saved = {
    products: readArray("products", mockProducts),
    categories: readArray("categories", mockCategories),
    orders: readArray("orders", mockOrders),
    inventory: readArray("inventory", mockInventory),
    audit: readArray("audit", mockAuditLogs),
    cart: readArray("cart", []),
  };
  if (readStorage("sulitcart:catalog-version", null) === catalogVersion) return saved;

  // Refresh only old demo records; keep custom catalog additions and real prototype history.
  const retainedProducts = saved.products.filter((product) => !legacyProductIds.has(product.id));
  const customCategoryIds = new Set(retainedProducts.map((product) => product.category));
  const retainedCategories = saved.categories.filter((category) => !legacyCategoryIds.has(category.id) || customCategoryIds.has(category.id));
  const products = mergeCatalog(retainedProducts, mockProducts);
  const inventory = refreshSampleRecords(saved.inventory, mockInventory).map((entry) => ({
    ...entry,
    productName: entry.productName || saved.products.find((product) => product.id === entry.productId)?.name,
  }));

  return {
    products,
    categories: mergeCatalog(retainedCategories, mockCategories),
    orders: refreshSampleRecords(saved.orders, mockOrders),
    inventory,
    audit: refreshSampleRecords(saved.audit, mockAuditLogs),
    cart: saved.cart.filter((line) => products.some((product) => product.id === line.productId && product.active && product.stock > 0))
      .map((line) => ({ ...line, quantity: Math.min(line.quantity, products.find((product) => product.id === line.productId).stock) })),
  };
}