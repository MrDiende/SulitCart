import { daysAgo } from "./mockDates";

export const mockInventory = [
  { id: "tx-001", productId: "p-ele-001", type: "Stock received", quantity: 12, date: daysAgo(0, 8), user: "Lea Navarro", note: "Headphones supplier delivery" },
  { id: "tx-002", productId: "p-ele-002", type: "Stock adjustment", quantity: -3, date: daysAgo(1, 16), user: "Lea Navarro", note: "Damaged packaging" },
  { id: "tx-003", productId: "p-hom-001", type: "Stock received", quantity: 20, date: daysAgo(2, 9), user: "Lea Navarro", note: "Home essentials delivery" },
  { id: "tx-004", productId: "p-sho-002", type: "Stock adjustment", quantity: -4, date: daysAgo(3, 14), user: "Lea Navarro", note: "Inventory count correction" },
];