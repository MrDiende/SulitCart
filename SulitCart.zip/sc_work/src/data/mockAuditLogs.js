import { daysAgo } from "./mockDates";
import { mockOrders } from "./mockOrders";
import { mockProducts } from "./mockProducts";

export const mockAuditLogs = [
  { id: "log-1", date: daysAgo(0, 9), user: "Lea Navarro", role: "Admin", action: "Order reviewed", entity: mockOrders[0].number, description: "Pending online order reviewed" },
  { id: "log-2", date: daysAgo(0, 8), user: "Lea Navarro", role: "Admin", action: "Stock received", entity: mockProducts[0].name, description: "12 items added to inventory" },
  { id: "log-3", date: daysAgo(1, 10), user: "Marco Santos", role: "Staff", action: "Order status changed", entity: mockOrders[2].number, description: "Confirmed to Packed" },
];