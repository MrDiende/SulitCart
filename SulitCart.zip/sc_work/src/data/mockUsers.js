export const mockUsers = [
  { id: "u-100", name: "Jamie Rivera", email: "customer@sulitcart.ph", phone: "0917 123 4567", role: "customer", active: true, address: "Kapitan Pepe, Cabanatuan City" },
  { id: "u-200", name: "Lea Navarro", email: "admin@sulitcart.ph", phone: "0917 555 0100", role: "admin", active: true },
  { id: "u-300", name: "Marco Santos", email: "staff@sulitcart.ph", phone: "0917 555 0200", role: "staff", active: true },
];

export const demoPassword = "demo1234";