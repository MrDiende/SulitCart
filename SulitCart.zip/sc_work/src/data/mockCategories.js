export const mockCategories = [
  { id: "electronics", name: "Electronics", description: "Everyday gadgets, audio, and useful tech accessories." },
  { id: "home-living", name: "Home & Living", description: "Thoughtful essentials for a comfortable, organized home." },
  { id: "clothing-apparel", name: "Clothing & Apparel", description: "Easy-to-wear basics and casual wardrobe favorites." },
  { id: "shoes-footwear", name: "Shoes & Footwear", description: "Comfortable sneakers and footwear for everyday plans." },
  { id: "beauty-personal-care", name: "Beauty & Personal Care", description: "Simple skincare and personal care essentials." },
];