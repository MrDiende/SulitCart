import { mockProducts } from "./mockProducts";
import { daysAgo } from "./mockDates";

const year = new Date().getFullYear();

function sampleOrder({ selections, shipping, ...details }) {
  const items = selections.map(([productId, quantity]) => {
    const product = mockProducts.find((item) => item.id === productId);
    return { productId, name: product.name, price: product.price, image: product.image, quantity };
  });
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  return { ...details, channel: "online", items, subtotal, shipping, total: subtotal + shipping, payment: "Cash on Delivery" };
}

export const mockOrders = [
  sampleOrder({ id: "o-1048", number: `SC-${year}-1048`, customerId: "u-101", customer: "Maria Santos", email: "maria.santos@email.com", date: daysAgo(0, 9), selections: [["p-ele-001", 1], ["p-bea-001", 1]], shipping: 50, status: "Pending", address: "Kapitan Pepe, Cabanatuan City", phone: "0917 234 5678" }),
  sampleOrder({ id: "o-1047", number: `SC-${year}-1047`, customerId: "u-102", customer: "Jose Dela Cruz", email: "jose.dc@email.com", date: daysAgo(1, 15), selections: [["p-hom-001", 2], ["p-hom-003", 1]], shipping: 60, status: "Confirmed", address: "San Isidro, Gapan City", phone: "0920 555 0192" }),
  sampleOrder({ id: "o-1046", number: `SC-${year}-1046`, customerId: "u-103", customer: "Ana Reyes", email: "ana.reyes@email.com", date: daysAgo(1, 10), selections: [["p-clo-001", 2], ["p-clo-002", 1]], shipping: 55, status: "Packed", address: "Bangad, Cabanatuan City", phone: "0998 110 6084" }),
  sampleOrder({ id: "o-1045", number: `SC-${year}-1045`, customerId: "u-104", customer: "Paolo Garcia", email: "paolo.g@email.com", date: daysAgo(2, 17), selections: [["p-sho-001", 1]], shipping: 75, status: "Shipped", address: "San Roque, San Jose City", phone: "0919 876 1023" }),
  sampleOrder({ id: "o-1044", number: `SC-${year}-1044`, customerId: "u-101", customer: "Maria Santos", email: "maria.santos@email.com", date: daysAgo(3, 11), selections: [["p-bea-002", 2], ["p-bea-003", 1]], shipping: 50, status: "Completed", address: "Kapitan Pepe, Cabanatuan City", phone: "0917 234 5678" }),
  sampleOrder({ id: "o-1043", number: `SC-${year}-1043`, customerId: "u-105", customer: "Liza Mendoza", email: "liza.m@email.com", date: daysAgo(4, 13), selections: [["p-ele-002", 1]], shipping: 60, status: "Cancelled", address: "San Isidro, Talavera", phone: "0918 223 4477" }),
];