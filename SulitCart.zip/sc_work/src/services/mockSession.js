export const mockSessionKey = "sulitcart:user";
const validRoles = new Set(["customer", "staff", "admin"]);
let lastSavedAt = 0;

export function publicSessionUser(account) {
  if (!account || typeof account.id !== "string" || typeof account.email !== "string" || !validRoles.has(account.role)) return null;
  const { credentials, password, ...profile } = account;
  return profile;
}

function readSessionRecord(storageName) {
  try {
    const raw = window[storageName].getItem(mockSessionKey);
    if (raw === null) return null;
    const saved = JSON.parse(raw);
    const isRecord = saved?.version === 1 && Object.prototype.hasOwnProperty.call(saved, "user");
    const account = isRecord ? saved.user : saved;
    const updatedAt = isRecord ? Number(saved.updatedAt) : 0;
    if (!Number.isFinite(updatedAt) || updatedAt < 0) return null;
    const user = account === null ? null : publicSessionUser(account);
    if (account !== null && !user) return null;
    return { user, updatedAt };
  } catch {
    return null;
  }
}

export function restoreMockSession(accounts) {
  const records = [readSessionRecord("localStorage"), readSessionRecord("sessionStorage")].filter(Boolean);
  const latest = records.reduce((current, record) => !current || record.updatedAt > current.updatedAt ? record : current, null);
  if (latest) lastSavedAt = Math.max(lastSavedAt, latest.updatedAt);
  if (!latest?.user || latest.user.active === false) return null;
  const account = accounts.find((item) => item.id === latest.user.id);
  return account && account.active !== false ? publicSessionUser(account) : null;
}

export function persistMockSession(account) {
  const user = account === null ? null : publicSessionUser(account);
  if (account !== null && !user) return false;
  lastSavedAt = Math.max(Date.now(), lastSavedAt + 1);
  const serialized = JSON.stringify({ version: 1, user, updatedAt: lastSavedAt });
  let saved = false;

  // Save before navigation; the tab copy also survives Request Desktop Site reloads.
  for (const storageName of ["localStorage", "sessionStorage"]) {
    try {
      window[storageName].setItem(mockSessionKey, serialized);
      saved = true;
    } catch {
      // Try the other storage when the browser blocks one or its quota is full.
    }
  }
  return saved;
}

export function persistMockAccounts(accounts) {
  try {
    window.localStorage.setItem("sulitcart:users", JSON.stringify(accounts));
    return null;
  } catch {
    return { error: "Your account changes could not be saved. Enable browser storage or free up space and try again." };
  }
}